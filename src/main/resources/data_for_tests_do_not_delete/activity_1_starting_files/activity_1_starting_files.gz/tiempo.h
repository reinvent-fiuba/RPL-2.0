#include <stdlib.h>

int segundos_a_horas_minutos_segundos(int tiempo_ingresado, int *horas, int *minutos, float *segundos);